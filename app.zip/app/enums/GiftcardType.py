from enum import Enum

class GiftcardType(Enum):
    Outrageous_BuildersClub = 0
    Turbo_BuildersClub = 1
    RobuxCurrency = 2
    TixCurrency = 3
    Item = 4