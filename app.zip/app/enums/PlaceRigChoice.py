from enum import Enum

class PlaceRigChoice( Enum ):
    UserChoice = 0
    ForceR6 = 1
    ForceR15 = 2