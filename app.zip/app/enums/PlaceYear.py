from enum import Enum

class PlaceYear( Enum ):
    Nine = 2009
    Ten = 2010
    Eleven = 2011
    Twelve = 2012
    Thirteen = 2013
    Fourteen = 2014
    Fifteen = 2015
    Sixteen = 2016
    Seventeen = 2017
    Eighteen = 2018
    Nineteen = 2019
    Twenty = 2020
    TwentyOne = 2021
    TwentyTwo = 2022
