from enum import Enum

class ChatStyle(Enum):
    Classic = 0
    Bubble = 1
    ClassicAndBubble = 2