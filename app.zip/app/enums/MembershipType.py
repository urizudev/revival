from enum import Enum

class MembershipType( Enum ):
    NonBuildersClub = 0
    BuildersClub = 1
    TurboBuildersClub = 2
    OutrageousBuildersClub = 3